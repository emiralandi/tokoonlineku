// Link /exec aplikasimu dari Apps Script (Terapkan → Kelola deployment).
window.APP_LINK = "https://tokokita-online-store-bmwrab.zedeai2026.workers.dev";
