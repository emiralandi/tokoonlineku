// Link /exec aplikasimu dari Apps Script (Terapkan → Kelola deployment).
window.APP_LINK = "https://tokokita-bmwrzb.zedeai2026.workers.dev";
