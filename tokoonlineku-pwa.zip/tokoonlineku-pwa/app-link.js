// Link /exec aplikasimu dari Apps Script (Terapkan → Kelola deployment).
window.APP_LINK = "https://tokoonlineku-bmwqkh.zedeai2026.workers.dev";
